package com.escape;

public class characters {

	public String removeSpecialCharacter(String text) {
		System.out.println(text);
	    System.out.println(text.replaceAll("[^a-zA-Z0-9\\s+]",""));
		return text.replaceAll("[^a-zA-Z0-9\\s+]","");
		}

}
